import 'package:flutter/material.dart';
import 'package:photo_tagger/pages/root.dart';

void main() {
  runApp(const PhotoTaggerApp());
}
