import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:photo_tagger/pages/drawer.dart';
import 'package:photo_tagger/pages/bar.dart';

class PhotoTaggerApp extends StatelessWidget {
  const PhotoTaggerApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: 'Photo tager',
      home: RootPage(),
    );
  }
}

class RootPage extends StatelessWidget {
  const RootPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      drawer: NavDrawer(),
      appBar: MainBar(),
      body: RootBody(),
      floatingActionButton: AddPhotoButton(),
    );
  }
}

class RootBody extends StatelessWidget {
  const RootBody({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        'Dodaj zdjęcie',
        style: TextStyle(
          color: Colors.grey,
          fontSize: 40,
        ),
      ),
    );
  }
}

class AddPhotoButton extends StatelessWidget {
  const AddPhotoButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton(
      onPressed: () => _addPhoto(),
      child: const Icon(Icons.add),
    );
  }

  void _addPhoto() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['jpg', 'pdf', 'png', 'svg', 'jpeg', 'bmp', 'tiff'],
    );

    if (result != null) {
      PlatformFile file = result.files.first;
      print(file.name);
    }
  }
}
