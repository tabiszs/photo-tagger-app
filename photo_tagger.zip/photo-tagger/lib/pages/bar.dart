import 'package:flutter/material.dart';

class MainBar extends StatelessWidget implements PreferredSizeWidget {
  const MainBar({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      title: const Text('Photo tagger'),
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(50);
}
