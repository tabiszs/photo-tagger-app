import 'package:flutter/material.dart';

class NavDrawer extends StatelessWidget {
  const NavDrawer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Container(
        //color: ThemeMode.of(context),
        child: ListView(
          children: [
            const Divider(
              thickness: 1,
            ),
            const Text('Dodaj zdjęcia'),
            const Text('Przeglądaj zdjęcia'),
            const Text('Widok katalogów'),
            const Text('Edytuj zdjęcie'),
            const Text('Wyszukaj zdjęcia'),
            const Text('O aplikacji'),
            const Divider(
              thickness: 1,
            ),
            Center(
              child: ElevatedButton(
                onPressed: () => {},
                child: const Text('Wyloguj'),
              ),
            )
          ],
        ),
      ),
    );
  }
}
