package edu.pw.photo_tagger

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
